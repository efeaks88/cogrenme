﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace int_değişkenler
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //kısa kenarı 10 uzun kenarı 20 olan dikdörtgenin alan ve çevresini hesaplayan bi kod
            //int uzunkenar, kısakenar, alan, cevre;
            //uzunkenar = 20;
            //kısakenar = 10;
            //alan = uzunkenar * kısakenar;
            //cevre = kısakenar * 2 + uzunkenar * 2;
            //label1.Text = "Alan: " + alan + " Çevre: " + cevre;
            //3 sınav notu girilen öğrencinin ortalama notunu hesaplayan kod ödevler
            //int sınav1, sınav2, sınav3, ortalama;
            //sınav1 = 80;
            //sınav2 = 50;
            //sınav3 = 20;
            //ortalama = (sınav1 + sınav2 + sınav3) / 3;
            //label1.Text = "Ortalama = " + ortalama;

        }
    }
}
